# TwitterAdvSearch
A scraping tool to scrape tweets with user provided keywords and hashtags, in a given data range.

## Usage
Type `python --version` in the terminal to check that python3 is installed.

Type `pip install -r requirements.txt` in the terminal to install all the external dependencies.

Type `python scraper.py` in the terminal from the directory that you cloned to run the program.

Follow the instruction from the script to do advanced searches on Twitter 